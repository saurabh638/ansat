<?php 

   include('config.php');

   $con = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database) or die("Oops something went wrong!");  
    
   if($_SERVER["REQUEST_METHOD"] == "POST") { 
      // username and password sent from form  
       
      $username = mysqli_real_escape_string($con,$_POST['username']); 
      $password = mysqli_real_escape_string($con,$_POST['password']); 
      $user_type = mysqli_real_escape_string($con,$_POST['user_type']); 
       
	  if($_POST['user_type']=='client'){
      $sql = "SELECT userid FROM user WHERE username = '$username' and password = '$password' and user_type = 'client'"; 
      $result = mysqli_query($con,$sql); 
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC); 
      $active = $row['active']; 
       
      $count = mysqli_num_rows($result); 
       
      // If result matched $username and $password, table row must be 1 row 
         
      if($count == 1) { 
         $_SESSION['username'] = $username; 
           header('location: index.html');
      }else { 
         echo "<script>alert('Your Login Name or Password is invalid')</script>"; 
      }
      }	  
	  
	  
	  if($_POST['user_type']=='author'){
      $sql = "SELECT userid FROM user WHERE username = '$username' and password = '$password' and user_type = 'author'"; 
      $result = mysqli_query($con,$sql); 
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC); 
      $active = $row['active']; 
       
      $count = mysqli_num_rows($result); 
       
      // If result matched $username and $password, table row must be 1 row 
         
      if($count == 1) { 
         $_SESSION['username'] = $username; 
           header('location: index.html');
      }else { 
         echo "<script>alert('Your Login Name or Password is invalid')</script>"; 
      }
      }	  
   } 
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>WELCOME|ANSAT Login</title>
    <link rel="stylesheet" type="text/css" href="css/normalize.css" />
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/component.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css" />
    <script src="js/modernizr.custom.js"></script>
    <script src="js/jquery-3.1.0.min.js"></script>

</head>
<body>
<div class="login-page">
    <div class="form">
        <form method="post">
            <input required type="text" placeholder="Username" name="username">
			<input required type="password" placeholder="Username" name="password">
			<select name="user_type">
			    <option value="client">Client</option>
				<option value="author">Author</option>
			</select>
            <input type="submit" name="register" style="color: #000"><p style="color: #fff"></p>
            <p class="message">New user? <a href="register.php">Register here</a></p>
        </form>
    </div>
</div>
</body>
</html>